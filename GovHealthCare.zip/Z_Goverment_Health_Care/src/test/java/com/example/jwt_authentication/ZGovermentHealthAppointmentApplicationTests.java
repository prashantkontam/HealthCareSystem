package com.example.jwt_authentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZGovermentHealthAppointmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
