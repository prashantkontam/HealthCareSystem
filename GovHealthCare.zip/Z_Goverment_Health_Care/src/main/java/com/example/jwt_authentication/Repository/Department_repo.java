package com.example.jwt_authentication.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.jwt_authentication.Model.Department;

public interface Department_repo extends JpaRepository<Department, Integer>
{
  
}
