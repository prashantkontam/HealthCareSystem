package com.example.jwt_authentication.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.jwt_authentication.Model.Home;
import com.example.jwt_authentication.Repository.Home_Repo;

@Component
public class Home_Service 
{
   @Autowired
   private Home_Repo home_Repo;
   
   public Home getHome() 
   {
	return home_Repo.findById(1);   
   }
}
