package com.example.jwt_authentication.Service;

public class Departments_Service {

}
