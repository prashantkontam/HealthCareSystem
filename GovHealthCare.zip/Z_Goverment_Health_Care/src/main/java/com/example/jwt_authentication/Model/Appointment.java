package com.example.jwt_authentication.Model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Appointment 
{
 @Id	
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private int A_id;
 private int  doc_id;
 private int p_id;
 private int slot;
 private String Problem;
 private String Status;
 private int hos_id;
 private LocalDate appointment_date;
 private int Feedback_Status;
 
public Appointment() {
	super();
	// TODO Auto-generated constructor stub
}

public int getA_id() {
	return A_id;
}

public void setA_id(int a_id) {
	A_id = a_id;
}

public int getDoc_id() {
	return doc_id;
}

public void setDoc_id(int doc_id) {
	this.doc_id = doc_id;
}


public int getP_id() {
	return p_id;
}


public void setP_id(int p_id) {
	this.p_id = p_id;
}

public int getSlot() {
	return slot;
}

public void setSlot(int slot) {
	this.slot = slot;
}

public String getProblem() {
	return Problem;
}
public void setProblem(String problem) {
	Problem = problem;
}

public String getStatus() {
	return Status;
}

public void setStatus(String status) {
	Status = status;
}

public int getHos_id() {
	return hos_id;
}

public void setHos_id(int hos_id) {
	this.hos_id = hos_id;
}


public LocalDate getAppointment_date() {
	return appointment_date;
}
public void setAppointment_date(LocalDate appointment_date) {
	this.appointment_date = appointment_date;
}



public int getFeedback_Status() {
	return Feedback_Status;
}

public void setFeedback_Status(int feedback_Status) {
	Feedback_Status = feedback_Status;
}

@Override
public String toString() {
	return "Appointment [A_id=" + A_id + ", doc_id=" + doc_id + ", p_id=" + p_id + ", slot=" + slot + ", Problem="
			+ Problem + ", Status=" + Status + ", hos_id=" + hos_id + ", appointment_date=" + appointment_date
			+ ", Feedback_Status=" + Feedback_Status + "]";
}




}
