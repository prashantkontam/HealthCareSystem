package com.example.jwt_authentication.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



@Entity
public class Receptionist 
{
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private int id;
 @Column(unique=true)
 private long Aadharno;
 private String usename;
 private String Password;
 private String name;
 private String role;
 private String bdate;
 private String mobile;
 private String city;
 private String Address;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public long getAadharno() {
	return Aadharno;
}
public void setAadharno(long aadharno) {
	Aadharno = aadharno;
}
public String getUsename() {
	return usename;
}
public void setUsename(String usename) {
	this.usename = usename;
}
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getBdate() {
	return bdate;
}
public void setBdate(String bdate) {
	this.bdate = bdate;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}
public Receptionist() {
	super();
	// TODO Auto-generated constructor stub
}
public String getMobile() {
	return mobile;
}
public void setMobile(String mobile) {
	this.mobile = mobile;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
@Override
public String toString() {
	return "Receptionist [id=" + id + ", Aadharno=" + Aadharno + ", usename=" + usename + ", Password=" + Password
			+ ", name=" + name + ", role=" + role + ", bdate=" + bdate + ", mobile=" + mobile + ", city=" + city
			+ ", Address=" + Address + "]";
}




}
