package com.example.jwt_authentication.Service;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.jwt_authentication.Model.Appointment;
import com.example.jwt_authentication.Repository.Receptionist_repo;

@Component
public class ReceptionistService 
{	
   @Autowired
   Receptionist_repo receptionist_repo;
   
   
   List<Appointment> getTodayAppointment(int hos_id, Date today)
   {
	   return receptionist_repo.findAllAppointmant(hos_id, today);
   }
}
