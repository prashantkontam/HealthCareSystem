package com.example.jwt_authentication.Model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;



@Entity
public class Department implements Serializable
{
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private int id;
 
 @ManyToOne
 @JoinColumn(name ="hosp_id")
 @JsonBackReference
 private Hospital hosp_id;
 private int Doc_id;
 private String departName;
 private String Description;
 
 
 
 
 public Department() {
	super();
 }
 
 
 public int getId() {
	return id;
}


public void setId(int id) {
	this.id = id;
}


@JsonBackReference
public Hospital gethosp_id() {
	return hosp_id;
 }
 
 public void sethosp_id(Hospital hosp_id) {
	hosp_id = hosp_id;
 }
 
 public String getDepartName() {
	return departName;
 }
 public void setDepartName(String departName) {
	this.departName = departName;
 }
 public String getDescription() {
	return Description;
 }
 public void setDescription(String description) {
	Description = description;
 }


public int getDoc_id() {
	return Doc_id;
}


public void setDoc_id(int doc_id) {
	Doc_id = doc_id;
}


@Override
public String toString() {
	return "Department [id=" + id + ", Hosp_id=" + hosp_id + ", Doc_id=" + Doc_id + ", departName=" + departName
			+ ", Description=" + Description + "]";
}
 
}
