package com.example.jwt_authentication.Model;

import java.util.List;

public class ViewAppointment {
	
	Appointment appointment;
	List<Description> AppointmentDescription;
	Doctor doctor;
	Patient pat;
	Hospital hos;
	
	
	
	public ViewAppointment() {
		super();
	}
	public Appointment getAppointment() {
		return appointment;
	}
	public void setAppointment(Appointment appointment) {
		this.appointment = appointment;
	}
	public List<Description> getAppointmentDescription() {
		return AppointmentDescription;
	}
	public void setAppointmentDescription(List<Description> appointmentDescription) {
		AppointmentDescription = appointmentDescription;
	}
	public Doctor getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}
	public Patient getPat() {
		return pat;
	}
	public void setPat(Patient pat) {
		this.pat = pat;
	}
	public Hospital getHos() {
		return hos;
	}
	public void setHos(Hospital hos) {
		this.hos = hos;
	}
	@Override
	public String toString() {
		return "ViewAppointment [appointment=" + appointment + ", AppointmentDescription=" + AppointmentDescription
				+ ", doctor=" + doctor + ", pat=" + pat + ", hos=" + hos + "]";
	}
	
	
	
	

}
