package com.example.jwt_authentication.Controller;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.jwt_authentication.Model.Appointment;
import com.example.jwt_authentication.Model.Feedback;
import com.example.jwt_authentication.Model.Patient;
import com.example.jwt_authentication.Model.User;
import com.example.jwt_authentication.Service.AppointmentService;
import com.example.jwt_authentication.Service.FeedbackService;
import com.example.jwt_authentication.Service.PatientService;
import java.time.LocalDate;


@RestController
public class Patient_controller {
	
	@Autowired
	PatientService patientService;
	
	@Autowired
	FeedbackService fs;
	
	@Autowired
	AppointmentService as;
	
	  @PostMapping("/Register")
	  @CrossOrigin(origins = "*", allowedHeaders = "*")
	  public void Register(@RequestBody Patient patient) throws Exception
	  {
		  String username=patient.getUsername();
		  Patient u=null;

		  
			if(username!=null && !"".equals(username))
			  {
				  u=patientService.login(patient.getUsername(), patient.getPassword());
				  if(u!=null) 
				  {
					  throw new Exception("User with this"+patient.getUsername()+" id already exist !");
				  }
			  }
		  
		  u=patientService.RegisterUser(patient);
		  
	  }
	  
	  @PostMapping("/login")
	  @CrossOrigin(origins = "*", allowedHeaders = "*")
      public Patient Login(@RequestBody User user ) throws Exception
	  {
		  System.out.println(user);
		  Patient patient=patientService.login(user.getUsername(), user.getPassword());
		  System.out.println(patient);
		  return patient;
		  

	  }
	  
	  @GetMapping("/getPatient/{id}")
	  @CrossOrigin(origins = "*", allowedHeaders = "*")
	  public Patient getPatientwithId(@PathVariable String id) 
	  {
		  return this.patientService.getPatient(Integer.parseInt(id));
		  
	  }
	  
	  @PostMapping("/fillfeedback")
	  @CrossOrigin(origins = "*", allowedHeaders = "*")
	  public Feedback fillFeedback(@RequestBody Feedback feedback)
	  {
		  System.out.println(feedback);
		  LocalDate today=LocalDate.now();
		  
		  Appointment a=as.findBya_id(feedback.getAppointment_id());
		  a.setFeedback_Status(1);
		  return fs.fillFeedback(feedback);
	  }
	  

	  
	  
	  
	  
}
