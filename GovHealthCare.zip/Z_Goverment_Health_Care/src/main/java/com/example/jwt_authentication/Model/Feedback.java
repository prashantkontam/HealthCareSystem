package com.example.jwt_authentication.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Feedback 
{
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
 private int id;
 private int appointment_id; 
 private int doc_id;
 private int hos_id;
 private String aboutDoctor;
 private String feedbackdate;
 private String campus;
 private int doc_rating;
 private int Hos_rating;
 
public Feedback() {
	super();
	// TODO Auto-generated constructor stub
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getAboutDoctor() {
	return aboutDoctor;
}

public void setAboutDoctor(String aboutDoctor) {
	this.aboutDoctor = aboutDoctor;
}

public String getFeedbackdate() {
	return feedbackdate;
}

public void setFeedbackdate(String feedbackdate) {
	this.feedbackdate = feedbackdate;
}

public String getCampus() {
	return campus;
}

public void setCampus(String campus) {
	this.campus = campus;
}

public int getDoc_rating() {
	return doc_rating;
}

public void setDoc_rating(int doc_rating) {
	this.doc_rating = doc_rating;
}

public int getHos_rating() {
	return Hos_rating;
}

public void setHos_rating(int hos_rating) {
	Hos_rating = hos_rating;
}

public int getAppointment_id() {
	return appointment_id;
}

public void setAppointment_id(int appointment_id) {
	this.appointment_id = appointment_id;
}

public int getDoc_id() {
	return doc_id;
}

public void setDoc_id(int doc_id) {
	this.doc_id = doc_id;
}

public int getHos_id() {
	return hos_id;
}

public void setHos_id(int hos_id) {
	this.hos_id = hos_id;
}

@Override
public String toString() {
	return "Feedback [id=" + id + ", appointment_id=" + appointment_id + ", doc_id=" + doc_id + ", hos_id=" + hos_id
			+ ", aboutDoctor=" + aboutDoctor + ", feedbackdate=" + feedbackdate + ", campus=" + campus + ", doc_rating="
			+ doc_rating + ", Hos_rating=" + Hos_rating + "]";
}


 
 
}
