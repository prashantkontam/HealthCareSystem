package com.example.jwt_authentication.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Home 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String title; 
	private String info;
	private String creator ;
	private String contact_us;
	private String facebookLink;
	private String Youtube_link;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getContact_us() {
		return contact_us;
	}
	public void setContact_us(String contact_us) {
		this.contact_us = contact_us;
	}
	public String getFacebookLink() {
		return facebookLink;
	}
	public void setFacebookLink(String facebookLink) {
		this.facebookLink = facebookLink;
	}
	public String getYoutube_link() {
		return Youtube_link;
	}
	public void setYoutube_link(String youtube_link) {
		Youtube_link = youtube_link;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Home [id=" + id + ", title=" + title + ", info=" + info + ", creator=" + creator + ", contact_us="
				+ contact_us + ", facebookLink=" + facebookLink + ", Youtube_link=" + Youtube_link + "]";
	}

}
