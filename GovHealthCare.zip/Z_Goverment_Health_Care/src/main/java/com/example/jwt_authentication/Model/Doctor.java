package com.example.jwt_authentication.Model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;


@Entity
public class Doctor 
{
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private int doc_id;
 
 private int hos_id;
 
 @Column(unique=true)
 private long aadhar_no;
 private String username;
 private String password;
 private String fname;
 private String Role;
 private String lname;
 private String bdate;
 private Date joindate;
 private String mobile;
 private String pincode;
 private String address;
 private String status;
 private int  depart_id;
 
 
public Doctor() {
	super();
	// TODO Auto-generated constructor stub
}



public String getRole() {
	return Role;
}

public void setRole(String role) {
	Role = role;
}

public int getDepart_id() {
	return depart_id;
}



public void setDepart_id(int depart_id) {
	this.depart_id = depart_id;
}



public int getDoc_id() {
	return doc_id;
}
public void setDoc_id(int doc_id) {
	this.doc_id = doc_id;
}
public int getHos_id() {
	return hos_id;
}
public void setHos_id(int hos_id) {
	hos_id = hos_id;
}
public long getAadhar_no() {
	return aadhar_no;
}
public void setAadhar_no(long aadhar_no) {
	this.aadhar_no = aadhar_no;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}
public String getBdate() {
	return bdate;
}
public void setBdate(String bdate) {
	this.bdate = bdate;
}
public Date getJoindate() {
	return joindate;
}
public void setJoindate(Date joindate) {
	this.joindate = joindate;
}

public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}



public String getMobile() {
	return mobile;
}



public void setMobile(String mobile) {
	this.mobile = mobile;
}



public String getPincode() {
	return pincode;
}



public void setPincode(String pincode) {
	this.pincode = pincode;
}



@Override
public String toString() {
	return "Doctor [doc_id=" + doc_id + ", Hos_id=" + hos_id + ", aadhar_no=" + aadhar_no + ", username=" + username
			+ ", password=" + password + ", fname=" + fname + ", Role=" + Role + ", lname=" + lname + ", bdate=" + bdate
			+ ", joindate=" + joindate + ", mobile=" + mobile + ", pincode=" + pincode + ", address=" + address
			+ ", status=" + status + ", depart_id=" + depart_id + "]";
}






 
 
}
