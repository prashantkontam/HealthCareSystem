package com.example.jwt_authentication.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.jwt_authentication.Model.Hospital;
import com.example.jwt_authentication.Service.HospitalService;

@RestController
public class Hospital_Controller {
	
	@Autowired
	HospitalService HospitalService;

	  @GetMapping(value = "/Hospitals")
	  @CrossOrigin(origins = "*", allowedHeaders = "*")
	  public List<Hospital> Hospitals()
	  {
		  return HospitalService.findAllHospital();
	  }
	  
	  
	  @GetMapping(value = "/Hospital/{id}" )
	  @CrossOrigin(origins = "*", allowedHeaders = "*")
	  public Hospital HospitalById(@PathVariable("id") int id) 
	  {
		 return HospitalService.findByid(id);  
	  }

}
