package com.example.jwt_authentication.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.jwt_authentication.Model.Home;
import com.example.jwt_authentication.Service.Home_Service;

@RestController
public class Home_Controller {

	@Autowired
	Home_Service home_Service;
	
	  @RequestMapping(value = "/Home" ,method = RequestMethod.GET)
	  @CrossOrigin(origins = "*", allowedHeaders = "*")
	  public Home HospitalFront()
	  {
		  return home_Service.getHome();
	  }
	  
	
	  
	
}
