package com.example.jwt_authentication.Model;

import java.io.Serializable;
import java.util.List;
import com.fasterxml.jackson.annotation.ObjectIdGenerator;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;



@Entity
public class Hospital implements Serializable{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String Hospital_name;
	private String city;
	private String Address;
	private  String role;
	
	@OneToMany(mappedBy ="hosp_id")
	private List<Department> departments;
	public Hospital() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	private int receptionist_id;
	
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getHospital_name() {
		return Hospital_name;
	}
	public void setHospital_name(String hospital_name) {
		Hospital_name = hospital_name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	
	@JsonManagedReference
	public List<Department> getDepartments() {
		return departments;
	}
	
	public void setDepartments(List<Department> departments) {
		this.departments = departments;
	}
	public int getReceptionist_id() {
		return receptionist_id;
	}
	public void setReceptionist_id(int receptionist_id) {
		this.receptionist_id = receptionist_id;
	}
	@Override
	public String toString() {
		return "Hospital [id=" + id + ", Hospital_name=" + Hospital_name + ", city=" + city + ", Address=" + Address
				+ ", role=" + role + ", departments=" + departments + ", receptionist_id=" + receptionist_id + "]";
	}
	
	
	
	

}
