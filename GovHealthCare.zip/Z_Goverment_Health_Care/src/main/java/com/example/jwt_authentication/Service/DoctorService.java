package com.example.jwt_authentication.Service;
import java.util.*;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.jwt_authentication.Model.Appointment;
import com.example.jwt_authentication.Model.Description;
import com.example.jwt_authentication.Model.Doctor;
import com.example.jwt_authentication.Repository.Appointment_repo;
import com.example.jwt_authentication.Repository.Doctor_Repo;

@Component
public class DoctorService {
	
	@Autowired
	public Doctor_Repo doctorrepo;
	
	@Autowired
	public Appointment_repo appoint;
	
	public Doctor AddDoctor(Doctor doctor)
	{
		return doctorrepo.save(doctor);
	}
	
	public Doctor Login(String username ,String password) 
	{
		Doctor doctor=doctorrepo.findByusernameandpassword(username, password);
		return doctor;
	}
	
	public Doctor findByUsername(String  username) 
	{
		return doctorrepo.findByusername(username);
	}
	
	public List<Doctor> findAllDosctors(int Hid)
	{
		return doctorrepo.findDoctorByHid(Hid);
	}
	
	public boolean SaveDescription(List<Description> s) 
	{
		s.forEach((Description desc)->{System.out.println(desc);});
		return true;
		
	}
	
	public Doctor getDoctorById(int id) 
	{
		Doctor d= doctorrepo.findById(id);
		return d;
	}
	

}
