package com.example.jwt_authentication.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.jwt_authentication.Model.Doctor;

public interface Doctor_Repo extends JpaRepository<Doctor, Integer>
{
  Doctor findByusername(String username);
  
  @Query(value ="select * from Doctor where username=:username and password=:password",nativeQuery = true)
  Doctor findByusernameandpassword(@Param("username")String username,@Param("password")String password);

  @Query(value ="select * from Doctor where hos_id=:hos_id",nativeQuery = true)
  List<Doctor> findDoctorByHid(@Param("hos_id")int hos_id);
 
  @Query(value ="select * from Doctor where doc_id=:id",nativeQuery = true)
  Doctor findById(@Param("id")int id);

  
}
