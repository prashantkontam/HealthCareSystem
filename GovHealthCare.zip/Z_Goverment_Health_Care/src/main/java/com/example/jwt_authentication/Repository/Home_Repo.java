package com.example.jwt_authentication.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.jwt_authentication.Model.Home;

public interface Home_Repo extends JpaRepository<Home, Integer> 
{
  public Home findById(int id);
}
