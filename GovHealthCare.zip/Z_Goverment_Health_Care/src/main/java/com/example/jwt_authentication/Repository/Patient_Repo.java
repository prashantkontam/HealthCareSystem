package com.example.jwt_authentication.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.jwt_authentication.Model.Patient;

public interface Patient_Repo extends JpaRepository<Patient, Integer> 
{
  @Query(value = "select * from patient where username=:username and password=:password",nativeQuery = true)
  Patient findByusernameandPassword(@Param("username")String username,@Param("password")String password);
  
  @Query(value = "select * from patient where username=:username ",nativeQuery = true)
  Patient findByusername(@Param("username")String username);
  
  @Query(value = "select * from patient where aadharno=:aadharno",nativeQuery = true)
  Patient findByaadharno(@Param("aadharno")Long aadharno);
 
}
