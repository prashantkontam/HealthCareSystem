package com.example.jwt_authentication.Controller;

public class Department_controller 
{

}
