package com.example.jwt_authentication.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Health_Officer 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
  private int Health_Officer;
	@Column(unique=true)
	private Long aadharno;
	private String username;
	private String password;
	private String role;
	private String fname;
	private String lname;
	private String state;
	
	public Health_Officer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public String getRole() {
		return role;
	}



	public void setRole(String role) {
		this.role = role;
	}



	public int getHealth_Officer() {
		return Health_Officer;
	}

	public void setHealth_Officer(int health_Officer) {
		Health_Officer = health_Officer;
	}

	public Long getAadharno() {
		return aadharno;
	}

	public void setAadharno(Long aadharno) {
		this.aadharno = aadharno;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}



	@Override
	public String toString() {
		return "Health_Officer [Health_Officer=" + Health_Officer + ", aadharno=" + aadharno + ", username=" + username
				+ ", password=" + password + ", role=" + role + ", fname=" + fname + ", lname=" + lname + ", state="
				+ state + "]";
	}

	
  
}
