package com.example.jwt_authentication.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.jwt_authentication.Model.Hospital;

public interface HospitalRepo extends JpaRepository<Hospital, Integer>
{
	public Hospital findById(int id);
	
	@Query(value = "select * from hospital" ,nativeQuery = true)
	public List<Hospital> findAllHospital();
	
}
