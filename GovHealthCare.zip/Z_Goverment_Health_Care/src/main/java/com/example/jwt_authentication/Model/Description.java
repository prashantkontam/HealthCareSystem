package com.example.jwt_authentication.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Description {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int Appointment_id;
	private int p_id;
	private String medicine;
	private int qty;
	private String Dose;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAppointment_id() {
		return Appointment_id;
	}
	public void setAppointment_id(int appointment_id) {
		Appointment_id = appointment_id;
	}
	public String getMedicine() {
		return medicine;
	}
	public void setMedicine(String medicine) {
		this.medicine = medicine;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public String getDose() {
		return Dose;
	}
	public void setDose(String dose) {
		Dose = dose;
	}
	@Override
	public String toString() {
		return "Description [id=" + id + ", Appointment_id=" + Appointment_id + ", medicine=" + medicine + ", qty="
				+ qty + ", Dose=" + Dose + "]";
	}
	
	
	

}
