package com.example.jwt_authentication.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.jwt_authentication.Model.Description;

public interface Description_repo extends JpaRepository<Description, Integer>
{
  @Query(value = "select * from description where p_id =:pid", nativeQuery = true)
  List<Description> findAlldescription_Pid(@Param("pid")int pid);
  
  @Query(value = "select * from description where Appointment_id =:aid",nativeQuery = true)
  List<Description> findAlldescription_Aid(@Param("aid")int aid);
  
  
}
