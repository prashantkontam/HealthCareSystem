package com.example.jwt_authentication.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.jwt_authentication.Model.Description;
import com.example.jwt_authentication.Model.Patient;
import com.example.jwt_authentication.Repository.Description_repo;
import com.example.jwt_authentication.Repository.Patient_Repo;

@Component
public class PatientService 
{
	@Autowired
	Patient_Repo patientrepo;
	
	@Autowired
	Description_repo description_repo;
	
	public Patient RegisterUser(Patient patient) 
	{
		return patientrepo.save(patient);
	} 
	
	public Patient login(String username,String password) 
	{
		Patient patient=patientrepo.findByusernameandPassword(username, password);
		return patient;
	}
	
	public Patient getUser(String username) 
	{
		Patient p=patientrepo.findByusername(username);
		return p;
	}
	
	public List<Description> findAllAppointment(int aid)
	{
		return description_repo.findAlldescription_Aid(aid);
	}
	
	public Patient getPatient(int id) 
	{
		Optional<Patient> p= patientrepo.findById(id);
		Patient s=p.get();
		return s;
	}
	

}
