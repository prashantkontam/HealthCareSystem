package com.example.jwt_authentication.Model;

public class DoctorInfo {
	
	private Doctor doc;
	private Hospital hos;
	
	
	
	public DoctorInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Doctor getDoc() {
		return doc;
	}
	public void setDoc(Doctor doc) {
		this.doc = doc;
	}
	public Hospital getHos() {
		return hos;
	}
	public void setHos(Hospital hos) {
		this.hos = hos;
	}
	@Override
	public String toString() {
		return "DoctorInfo [doc=" + doc + ", hos=" + hos + "]";
	}
	
	
	
	

}
