package com.example.jwt_authentication.Controller;

import java.util.List;
import com.example.jwt_authentication.Model.User;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.jwt_authentication.Model.Appointment;
import com.example.jwt_authentication.Model.Description;
import com.example.jwt_authentication.Model.Doctor;
import com.example.jwt_authentication.Model.DoctorInfo;
import com.example.jwt_authentication.Model.Hospital;
import com.example.jwt_authentication.Service.AppointmentService;
import com.example.jwt_authentication.Service.DescriptionService;
import com.example.jwt_authentication.Service.DoctorService;
import com.example.jwt_authentication.Service.HospitalService;

@RestController
public class Doctor_Controller {
	
	@Autowired
	DoctorService doctor_service;
	
	@Autowired
	HospitalService HosSer;
	
	@Autowired
	AppointmentService as;
	
	@Autowired
	DescriptionService DescService;
	
	@PostMapping("/Dosctor")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	public Doctor RegisterDoctor(@RequestBody Doctor doc) throws Exception
	{
		String username=doc.getUsername();
		if(username!=null && !"".equals(username))
		  {
			  Doctor u=doctor_service.findByUsername(username);
			  if(u!=null) 
			  {
				  throw new Exception("User with this"+doc.getUsername()+" id already exist !");
			  }
		  }
		
		doctor_service.AddDoctor(doc);
		
	  return doc;
	} 
	
	@GetMapping(value = "/Doctors/{H_id}")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	public List<Doctor> getAllDoctor(@PathVariable String H_id)
	{
		return doctor_service.findAllDosctors(Integer.parseInt(H_id));
	}
	
	@PostMapping("AddDescription")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	public boolean SaveDescription(@RequestBody List<Description> p) 
	{
		System.out.println(p);
		//return doctor_service.SaveDescription(p);
		p.forEach((Description ds)  ->{
			Appointment a=as.findBya_id(ds.getAppointment_id());
			a.setStatus("done");
			as.save(a);
			DescService.saveDescription(ds);
		});
		
		return true;
	}
	
	
	
	@GetMapping(value = "/DoctorInfo/{id}")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	public DoctorInfo getDoctor(@PathVariable String id) 
	{
		Doctor d= doctor_service.getDoctorById(Integer.parseInt(id));
	   DoctorInfo doc=new DoctorInfo();
	   doc.setDoc(d);
	   Hospital hos= HosSer.findByid(d.getHos_id());
	   doc.setHos(hos);
	   
	   return doc;
	   
	}
	
	@PostMapping(value = "/DoctorLogin")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	public Doctor getDoctor(@RequestBody User id) 
	{
		Doctor d= doctor_service.Login(id.getUsername(), id.getPassword());
	  if(d==null) 
	  {
		  return null;
	  }
	  else{
		  return d;
	  }	   
	}
	
	

	
   


}
