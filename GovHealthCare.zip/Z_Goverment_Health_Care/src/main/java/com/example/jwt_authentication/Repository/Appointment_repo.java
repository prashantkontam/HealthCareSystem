package com.example.jwt_authentication.Repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.jwt_authentication.Model.Appointment;

public interface Appointment_repo extends JpaRepository<Appointment, Integer> {
 
 @Query(value = "select slot from appointment a where a.doc_id=:docid and a.appointment_date=:appoint_date", nativeQuery = true)
 List<Integer> findwithdateanddoc_id(@Param("docid")int id, @Param("appoint_date")LocalDate d);
 
 @Query(value = "select * from Appointment where p_id=:pid and status IS NOT NULL",nativeQuery = true)
 List<Appointment> findAllAppointment(@Param("pid")int p_id);
 

 @Query(value = "select * from appointment a where a.doc_id=:docid and a.appointment_date=:appoint_date and status='NULL'", nativeQuery = true)
 List<Appointment> findAppointmentOfdoc_id(@Param("docid")int id, @Param("appoint_date")LocalDate d);
 
 
 
}
