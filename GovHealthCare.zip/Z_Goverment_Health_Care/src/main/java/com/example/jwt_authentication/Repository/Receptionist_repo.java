package com.example.jwt_authentication.Repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.jwt_authentication.Model.Appointment;
import com.example.jwt_authentication.Model.Receptionist;

public interface Receptionist_repo extends JpaRepository<Receptionist, Integer>{
 
	@Query(value ="select * from Appointment where hos_id=:hos_id and apointment_date=:today" ,nativeQuery = true)
	List<Appointment> findAllAppointmant(@Param("hos_id")int hos_id, @Param("today")Date today );
}
