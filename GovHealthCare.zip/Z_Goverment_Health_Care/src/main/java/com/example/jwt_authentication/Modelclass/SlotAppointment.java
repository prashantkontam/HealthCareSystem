package com.example.jwt_authentication.Modelclass;

import java.sql.Date;
import java.time.LocalDate;

public class SlotAppointment {
	private int id;
	private LocalDate date;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	
	@Override
	public String toString() {
		return "SlotAppointment [id=" + id + ", date=" + date + "]";
	}
	
	

}
