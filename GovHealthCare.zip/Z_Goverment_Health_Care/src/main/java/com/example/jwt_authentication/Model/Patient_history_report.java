package com.example.jwt_authentication.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



@Entity
public class Patient_history_report 
{
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private int id;
 private int Appointmentid;
 private String diseases; 
public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public int getAppointmentid() {
	return Appointmentid;
}

public void setAppointmentid(int appointmentid) {
	Appointmentid = appointmentid;
}

public String getDiseases() {
	return diseases;
}

public void setDiseases(String diseases) {
	this.diseases = diseases;
}

public Patient_history_report() {
	super();
	// TODO Auto-generated constructor stub
}

@Override
public String toString() {
	return "Patient_history_report [id=" + id + ", Appointmentid=" + Appointmentid + ", diseases=" + diseases+"]";
}
 
 
}
