package com.example.jwt_authentication.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.jwt_authentication.Model.Hospital;
import com.example.jwt_authentication.Repository.HospitalRepo;

@Component
public class HospitalService 
{

	@Autowired
	public HospitalRepo hospitalrepo;
	
	public Hospital findByid(int id){
		Hospital hospital=hospitalrepo.findById(id);
		return hospital;
	}
	
	public List<Hospital> findAllHospital()
	{
		List<Hospital> allHospital=hospitalrepo.findAllHospital();
		return allHospital;
	}
	
	
}
