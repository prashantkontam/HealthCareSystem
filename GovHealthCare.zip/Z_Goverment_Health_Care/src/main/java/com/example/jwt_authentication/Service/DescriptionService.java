package com.example.jwt_authentication.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.jwt_authentication.Model.Description;
import com.example.jwt_authentication.Repository.Description_repo;

@Component
public class DescriptionService 
{
	@Autowired
	private Description_repo d_repo;
	
	public List<Description> getDescription(int id)
	{
		return d_repo.findAlldescription_Aid(id);
	}
	
	public Description saveDescription(Description d) 
	{
		return d_repo.save(d);
	}
	
}
