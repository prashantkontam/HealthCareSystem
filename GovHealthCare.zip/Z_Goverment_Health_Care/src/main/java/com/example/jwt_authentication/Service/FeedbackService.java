package com.example.jwt_authentication.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.jwt_authentication.Model.Feedback;
import com.example.jwt_authentication.Repository.Feedback_repo;

@Component
public class FeedbackService {
	
	 @Autowired
	 Feedback_repo feedbackrepo;
	 
	 public float getHospitalRating(int Hos_id) 
	 {
		 return feedbackrepo.findavgRatHos(Hos_id);
	 }
	 
	 public float getDoctorRating(int Doc_id) 
	 {
		 return feedbackrepo.findavgRatDoc(Doc_id);
	 }
	 
	 public List<Feedback> getAllDocfeed(int id)
	 {
		 return feedbackrepo.getAllDocfeedback(id);
	 }
	 

	 public List<Feedback> getAllHosfeed(int id)
	 {
		 return feedbackrepo.getAllHosfeedback(id);
	 }	  
	 
	 public Feedback fillFeedback(Feedback f) 
	 {
		 return feedbackrepo.save(f);
	 }

}
