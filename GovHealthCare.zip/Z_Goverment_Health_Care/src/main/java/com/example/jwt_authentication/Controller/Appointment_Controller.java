package com.example.jwt_authentication.Controller;

import java.io.UnsupportedEncodingException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.jwt_authentication.Model.Appointment;
import com.example.jwt_authentication.Model.Description;
import com.example.jwt_authentication.Model.Doctor;
import com.example.jwt_authentication.Model.Feedback;
import com.example.jwt_authentication.Model.Hospital;
import com.example.jwt_authentication.Model.Patient;
import com.example.jwt_authentication.Model.ViewAppointment;
import com.example.jwt_authentication.Modelclass.SlotAppointment;
import com.example.jwt_authentication.Service.AppointmentService;
import com.example.jwt_authentication.Service.DescriptionService;
import com.example.jwt_authentication.Service.DoctorService;
import com.example.jwt_authentication.Service.FeedbackService;
import com.example.jwt_authentication.Service.HospitalService;
import com.example.jwt_authentication.Service.PatientService;

@RestController
public class Appointment_Controller {
	
	@Autowired
	AppointmentService appointmentService;
	
	@Autowired
	DoctorService docservice;
	
	@Autowired
	HospitalService HosSer;
	
	@Autowired
	DescriptionService dservice;
	
	@Autowired
	PatientService pservice;
	
	@Autowired
	FeedbackService Fservice;
	
	@PostMapping("user/Appointment")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	public Appointment registerAppointment(@RequestBody Appointment app) throws Exception
	{		
		System.out.println(app);
		app.setStatus("NULL");
		app.setFeedback_Status(0);
		Patient patient=pservice.getPatient(app.getP_id());
		String email=patient.getUsername();
		String Pname=patient.getFname() +" "+patient.getLname();
		Doctor doc=docservice.getDoctorById(app.getDoc_id());
		String Docname=doc.getFname()+" "+doc.getLname();
		Hospital hos=HosSer.findByid(app.getHos_id());
		String HospitalName=hos.getHospital_name();
		
		String msg=appointmentService.getMessage(Pname, HospitalName, Docname);
		
		appointmentService.sendemail(msg, "Appointment Confirmed", email, "basecaseface@gmail.com");
		return appointmentService.addAppointment(app);
	}
	
	@PostMapping("user/Appointment/getSlot")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	public List<Integer> getSlot(@RequestBody SlotAppointment sl)
	{
	  System.out.println(sl);
	  return appointmentService.findAllAppointment(sl.getId(), sl.getDate());	
	}
	
	
	@GetMapping("/geAllslot/{id}")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	public List<Appointment> ListOfAppointment(@PathVariable String id)
	{
		return appointmentService.findallAppointmentsofId(Integer.parseInt(id));
	}
	
	@GetMapping("/getTodayAppointment/{id}")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	public List<Appointment> getTodayAppointment(@PathVariable String id)
	{
	  return appointmentService.findAppointmentWithDoc_Id(Integer.parseInt(id));	
	}
	
	@GetMapping("/getAppointment/prevAppointment/{id}")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	public ViewAppointment getAppointmentPrev(@PathVariable String id) 
	{
		ViewAppointment a1=new ViewAppointment();
		Appointment app=appointmentService.findBya_id(Integer.parseInt(id));
		Doctor doc= docservice.getDoctorById(app.getDoc_id());
		Hospital hos= HosSer.findByid(doc.getHos_id());
		List<Description> desc=dservice.getDescription(Integer.parseInt(id));
		Patient p=pservice.getPatient(app.getP_id());
		a1.setAppointment(app);
		a1.setAppointmentDescription(desc);
		a1.setHos(hos);
		a1.setDoctor(doc);
		a1.setPat(p);
		return a1;
	}  
	

	@GetMapping("/sentMessage")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
    public String sendEmailwithApi() throws UnsupportedEncodingException {

		String to = "priyanshisohani421@gmail.com";
		String subject = "Appointment Confirmed";
		String from = "basecaseface@gmail.com";
		String message = "This mail regarding Appointment has been Confirmed :) ";
	
		appointmentService.sendemail(message, subject, to, from);
	return message;
	
	} 
	
	
	@GetMapping("/getDocFeedback/{id}")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
    public List<Feedback> getDocfeed( @PathVariable String id)
	{
		return Fservice.getAllDocfeed(Integer.parseInt(id));
	}
	
	@GetMapping("/getHosFeedback/{id}")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
    public List<Feedback> getHosfeed( @PathVariable String id)
	{
		return Fservice.getAllHosfeed(Integer.parseInt(id));
	}
	
	@GetMapping("/getAvgDocRating/{id}")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
    public float getAvgDocrating( @PathVariable String id)
	{
		return Fservice.getDoctorRating(Integer.parseInt(id));
	}
	
	@GetMapping("/getAvgHosRating/{id}")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
    public float getAvgHosrating( @PathVariable String id)
	{
		return Fservice.getHospitalRating(Integer.parseInt(id));
	}
		

	@GetMapping("/AllAppointment")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
    public List<Appointment> getAllAppointment()
	{
		return appointmentService.findAll();
	}
		
	

}
